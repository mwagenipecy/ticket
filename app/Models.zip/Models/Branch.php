<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\MonthlyPaymentsStatus;
use App\Models\Expenses;


class Branch extends Model
{
    use HasFactory;
    protected $table = 'teams';


}
