<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class recon_sessions extends Model
{
    use HasFactory;
    protected $table = 'recon_sessions';
    protected $guarded = [];
}