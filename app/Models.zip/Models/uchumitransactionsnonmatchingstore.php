<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class uchumitransactionsnonmatchingstore extends Model
{
    use HasFactory;
    protected $table = 'uchumi_transactions_non_matching_store';
    protected $guarded = [];
}
