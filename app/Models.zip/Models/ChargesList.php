<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChargesList extends Model
{
    use HasFactory;

    protected $table='chargeslist';

    protected $guarded=[];

}
