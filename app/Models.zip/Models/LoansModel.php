<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoansModel extends Model
{
    use HasFactory;
    protected $table = 'loans';
    protected $guarded = [];


    public function loanProduct(){

        return $this->belongsTo(Loan_sub_products::class,'loan_sub_product','sub_product_id');
    }

    public function clientName(){
        return $this->hasOne(ClientsModel::class,'client_number','client_number');
    }

    public function loanBranch(){

        return $this->belongsTo(BranchesModel::class,'branch_id');
    }

}
