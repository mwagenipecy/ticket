<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class loans_arreas extends Model
{
    use HasFactory;
    protected $table = 'loans_arreas';
    protected $guarded = [];

}
